<?php
echo esc_html( __('jajajaja','listingpro-visualizer'));
?>