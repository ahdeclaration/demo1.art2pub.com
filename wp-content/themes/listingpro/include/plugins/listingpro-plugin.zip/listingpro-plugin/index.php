<?php
echo 'heehehhehehheh';
?>